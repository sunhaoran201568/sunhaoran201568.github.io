---
title: 关于
subtitle: 想了解我点的什么？
date: 2019-02-21 19:13:16
cover: https://qiniu.sukoshi.xyz/src/images/68135789_p0.jpg
aplayer: true
---

{% aplayer
  name="you（寒蝉鸣泣之时）伴奏"
  artist="M.Graveyard"
  url="https://qiniu.sukoshi.xyz/attach/2021/04/12/you%EF%BC%88%E5%AF%92%E8%9D%89%E9%B8%A3%E6%B3%A3%E4%B9%8B%E6%97%B6%EF%BC%89%E4%BC%B4%E5%A5%8F.mp3"
  cover="https://qiniu.sukoshi.xyz/attach/2021/04/12/you%EF%BC%88%E5%AF%92%E8%9D%89%E9%B8%A3%E6%B3%A3%E4%B9%8B%E6%97%B6%EF%BC%89%E4%BC%B4%E5%A5%8F.jpeg@webp"
%}

---

**ʚ 沃捏哇刚哒母 ɞ**

**「90后大叔です」** **「人怂话不多 小声BB」** **「伪二刺猿 呐,呐,呐」** **「死肥宅 肥宅针鹅心」** **「🏠里蹲 在家玩游戏它不香吗」** 

**「日语勉強をする 勉强自己学习」** **「前端切图仔 再往⬅️移动两个像素」** **「社畜 迟到的边缘试探」**

**「网抑☁️🎵 13岁,我好累」** **「守护最好的霹雳霹雳⚡️ 可能会倒闭,但绝不会变质」** **「逼乎 泻药,人在🇺🇸 刚下✈️」** **「GayHub 来一起♂玩耍」**

---

**ʚ 博客 ɞ**

基于[Hexo](https://hexo.io/zh-cn/)的一个个人博客，目的是偶尔 分享 记录 生活，写写笔记啥的。

主题使用的是自己开发的[flex-block](https://github.com/miiiku/flex-block)主题

如果你是使用`HUGO`的话，也可以试试[kagome](https://github.com/miiiku/hugo-theme-kagome)

---

**ʚ 如何修改自己的评论头像 ɞ**

进入https://cn.gravatar.com/

点击那个很瞩目的蓝色按钮 **“Create Your Own Gravatar”** 使用你的邮箱注册账号，上传你的头像就可以了

注意的是你的头像必须选择点击G-全年龄级
